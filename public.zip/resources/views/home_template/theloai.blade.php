<div class="card">
    <div class="card-header fw-bold">Thể loại</div>
    <div class="card-body d-flex flex-wrap gap-3">
        <button type="button" class="btn btn-primary position-relative">
            Thể loại
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>
        <button type="button" class="btn btn-primary position-relative">
            Thể loại <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">99+</span>
        </button>

    </div>
</div>