

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mb-5">
            <div class="card">
                <div class="card-header fw-bold">Tìm kiếm</div>
                <div class="card-body">
                    <form class="d-flex">
                        <input class="form-control me-2 w-75" type="search" placeholder="Nhập tên truyện cần tìm kiếm" aria-label="Search">
                        <button class="btn btn-outline-success w-25" type="submit">Tìm kiếm</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>