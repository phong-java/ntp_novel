<form method="POST" action="resources\views\user\xulythanhtonamomo.php" target="_blank" enctype="application/x-www-form-urlencoded">
    <input type="submit" name="momo" value="QR momo" class="btn btn-danger">
</form>