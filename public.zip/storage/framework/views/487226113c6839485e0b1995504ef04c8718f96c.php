<div class="card">
    <div class="card-header">Đánh dấu của bạn</div>
    <div class="card-body">
        <div class="overflow-auto ntp_custom_ver_scrollbar" style="height: 150px;">
            <div class="d-flex flex-row my-1 align-items-center justify-content-between">
                <a href="javascript:void(0);" class="title text-truncate text-decoration-none text-reset"> Tổng Mạn: Đồng Thời
                    Xuyên Qua Mở Ra Một Người Chat Group<br> Chương 62: Cho JOJO kịch thấu tử vong,
                    cho trăm tuổi lão nhân một kinh hỉ!
                </a>
                <a href="javascript:void(0);" class="btn btn-danger mx-2">X</a>
            </div>
            <div class="d-flex flex-row my-1 align-items-center justify-content-between">
                <a href="javascript:void(0);" class="title text-truncate text-decoration-none text-reset"> Kết thúc chư thiên:
                    Đồng thời xuyên qua 99 cái thế giới<br> Chương 08: Ngươi năm đời ta lục đại, có
                    hay không làm đầu ( Cầu Like truy đọc )
                </a>
                <a href="javascript:void(0);" class="btn btn-danger mx-2">X</a>
            </div>
            <div class="d-flex flex-row my-1 align-items-center justify-content-between">
                <a href="javascript:void(0);" class="title text-truncate text-decoration-none text-reset"> Y Đạo Vô Song<br>
                    Thứ 0001 chương: Có thể ngày mai là một ngày tốt lành
                </a>
                <a href="javascript:void(0);" class="btn btn-danger mx-2">X</a>
            </div>
            <div class="d-flex flex-row my-1 align-items-center justify-content-between">
                <a href="javascript:void(0);" class="title text-truncate text-decoration-none text-reset"> Đồng Thời Xuyên
                    Qua: Người Bình Thường Chỉ Có Mình Ta?<br> Chương 7: trời sinh thổ mộc Thánh
                    Thể!
                </a>
                <a href="javascript:void(0);" class="btn btn-danger mx-2">X</a>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/home_template/danhdau.blade.php ENDPATH**/ ?>