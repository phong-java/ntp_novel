<?php
use App\Models\Novel;
use App\Models\Bookmarks;
use Illuminate\Support\Facades\Auth;
?>


<div class="card ntp_bookmarks_card">
    <div class="card-header fw-bold">Đánh dấu của bạn</div>
    <div class="card-body">
        <?php if(Auth::check()): ?>
            <?php
                $iduser = Auth::user()->id;
                $bookmarks = Bookmarks::where('idUser', $iduser)->get();
            ?>
            <div class="overflow-auto ntp_bookmarks ntp_custom_ver_scrollbar" style="height: 200px;">
                <?php $__currentLoopData = $bookmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bookmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $novel = Novel::find($bookmark->idNovel);
                    ?>
                    <div class="d-flex flex-row my-1 align-items-center justify-content-between">
                        <a href="<?php echo e(route('Novel.show', [$novel->id])); ?>"
                            class="title text-truncate text-decoration-none text-reset"><?php echo e($novel->sNovel); ?></a>
                        <a href="javascript:void(0);" data-link="<?php echo e(route('Bookmark.bookmark_remove', [$novel->id])); ?>"
                            class="btn btn-danger ntp_bookmark_remove mx-2">X</a>
                    </div>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="overflow-auto ntp_bookmarks ntp_bookmarks_locall ntp_custom_ver_scrollbar" style="height: 200px;"></div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/user/user_bookmark.blade.php ENDPATH**/ ?>