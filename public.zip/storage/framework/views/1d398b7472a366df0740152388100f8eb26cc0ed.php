<div class="alert alert-danger" role="alert">
    
<?php if(auth()->guard()->guest()): ?>
    bạn đang truy cập trái phép trang không thuộc quyền truy cập của mình
<?php else: ?>
    <?php if(auth()->guard()->check()): ?>
    <?php echo e(Auth::user()->name); ?> bạn đang truy cập trái phép trang không thuộc quyền truy cập của mình
    <?php endif; ?>
<?php endif; ?>

</div>

<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/layouts/404_traiphep.blade.php ENDPATH**/ ?>