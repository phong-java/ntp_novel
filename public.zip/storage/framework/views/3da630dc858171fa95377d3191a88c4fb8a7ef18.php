<?php

use App\Models\User;
use App\Models\Author;
use App\Models\Novel;
use App\Models\Chapter;

$novels = Novel::orderBy('id', 'DESC')->get();
$title = 'Danh sách truyện';

?>

<div class="container" id="ntp_admin_novel_list_wrap">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold"><?php echo e($title); ?></div>
                <?php if(auth()->guard()->guest()): ?>
                    <div class="card-body">
                        <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php else: ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->sRole == 'admin'): ?>
                            <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 1000px;">
                                <table class="table table-hover ntp_novel_list">
                                    <thead>
                                        <tr>
                                            <th scope="col">STT</th>
                                            <th scope="col">Tên truyện</th>
                                            <th scope="col">Tác giả</th>
                                            <th scope="col">Ngày khởi tạo</th>
                                            <th scope="col">Số chương chưa qua kiểm duyệt</th>
                                            <th scope="col">Trạng thái</th>
                                            <th scope="col">Trạng thái xét duyệt</th>
                                            <th scope="col">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                        <?php $__currentLoopData = $novels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $novel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key + 1); ?></th>
                                                <td class="name"><?php echo e($novel->sNovel); ?></td>
                                                <td>
                                                    <?php
                                                    $author = Author::where('idUser', $novel->idUser)->first();
                                                    echo $author->sNickName;
                                                    ?>
                                                </td>
                                                <td><?php echo e($novel->dCreateDay); ?></td>
                                                <td>
                                                    <?php
                                                    $un_Publish_chapter_count = Chapter::where('idNovel', $novel->id)
                                                        ->where('iPublishingStatus', 0)
                                                        ->get()
                                                        ->count();
                                                    $chapter_count = Chapter::where('idNovel', $novel->id)
                                                        ->get()
                                                        ->count();
                                                    echo '<span class="text text-danger">' . $un_Publish_chapter_count . '</span> / ' . $chapter_count;
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php if($novel->iStatus == 1): ?>
                                                        <span class="text text-success">Đăng tải</span>
                                                    <?php else: ?>
                                                        <span class="text text-danger">Gỡ bỏ</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($novel->iLicense_Status == 0): ?>
                                                        <span class="text text-warning">Chưa xét duyệt</span>
                                                    <?php elseif($novel->iLicense_Status == 1): ?>
                                                        <span class="text text-success">Xét duyệt thành công</span>
                                                    <?php elseif($novel->iLicense_Status == 3): ?>
                                                        <span class="text text-danger">Xét duyệt thất bại</span>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <div class="btn-group ntp_dropdown">
                                                        <button type="button" class="btn dropdown-toggle"
                                                            data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-align-justify"></i> Tác vụ quản lý
                                                            truyện </button>
                                                        <ul class="dropdown-menu dropdown-menu-lg-end">
                                                            <li>
                                                                <a class="dropdown-item ntp_chitiettruyen"
                                                                    data-bs-toggle="modal" data-bs-target="#ntp_edit_novel_poup"
                                                                    href="javascript:void(0);"
                                                                    data-link="<?php echo e(route('Novel.chi_tiet_truyen', [$novel->id])); ?>"><i class="fa-solid fa-toolbox"></i> Quản lý truyện</a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(route('Novel.page_kiem_duyet_chuong', [$novel->id])); ?>"> <i class="fa-solid fa-file-circle-check"></i> Kiểm duyệt chương</a>
                                                            </li>
                                                        </ul>
                                                    </div>


                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="card-body">
                                <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/admincp/admin_page/admin_xetduyet_tacpham.blade.php ENDPATH**/ ?>