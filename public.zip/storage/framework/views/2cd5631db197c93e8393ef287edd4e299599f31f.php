<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold">Danh sách thể loại truyện</div>
                <?php if(auth()->guard()->guest()): ?>
                <div class="card-body">
                    <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php else: ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->sRole == 'admin'): ?>
                    <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 1000px;">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">STT</th>
                                    
                                    <th scope="col">Tên thể loại</th>
                                    <th scope="col">Trạng thái</th>
                                    <th scope="col">Ngày khởi tạo</th>
                                    <th scope="col">Cập nhật lần cuối</th>
                                    <th scope="col">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>


                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                        
                                        <td><?php echo e($cat->sCategories); ?></td>
                                        <td>
                                            <?php if($cat->iStatus == 1): ?>
                                                <span class="text text-success">kích hoạt</span>
                                            <?php else: ?>
                                                <span class="text text-danger">Không kích hoạt</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($cat->dCreateDay); ?></td>
                                        <td><?php echo e($cat->dUpdateDay); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-primary ntp_cat_edit" data-bs-toggle="modal" data-link="<?php echo e(route('Categories.show',[$cat -> id])); ?>" data-bs-target="#ntp_edit_cat_ppoup"> Chi tiết</a>    
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="card-body">
                            <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/admincp/Categories/index.blade.php ENDPATH**/ ?>