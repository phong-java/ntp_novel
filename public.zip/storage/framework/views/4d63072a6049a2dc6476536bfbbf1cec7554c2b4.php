<?php

use App\Models\User;
use App\Models\Author;

$authors = Author::orderBy('id', 'DESC')->get();

?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold">Danh sách người dùng xin cấp quyền tác giả</div>
                <?php if(auth()->guard()->guest()): ?>
                    <div class="card-body">
                        <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php else: ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->sRole == 'admin'): ?>
                            <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 1000px;">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">STT</th>
                                            
                                            <th scope="col">Tên người dùng</th>
                                            <th scope="col">Bút danh đăng ký</th>
                                            <th scope="col">Ngày xin cấp</th>
                                            <th scope="col">Tình trạng xét duyệt</th>
                                            <th scope="col">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                    foreach ($authors as $key => $author) {
                                        $user = User::find($author->idUser);
                                        ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            
                                            <td><?php echo e($user->name); ?></td>
                                            <td ><?php echo e($author->sNickName); ?></td>
                                            <td><?php echo e($author->dCreateDay); ?></td>
                                            <td>
                                                <?php if($author->iStatus == 0): ?>
                                                    <span class="text text-warning">Chưa xét duyệt</span>
                                                <?php elseif($author->iStatus == 1): ?>
                                                    <span class="text text-success">Xét duyệt thành công</span>
                                                <?php elseif($author->iStatus == 3): ?>
                                                    <span class="text text-danger">Xét duyệt bị từ chối</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="#" class="btn btn-primary ntp_btn_author_detail" data-bs-toggle="modal" data-bs-target="#ntp_author_detail"
                                                    data-link="<?php echo e(route('Author.edit', [$author->id])); ?>"
                                                    > Chi tiết</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="card-body">
                                <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/admincp/admin_page/admin_xetduyet_tacgia.blade.php ENDPATH**/ ?>