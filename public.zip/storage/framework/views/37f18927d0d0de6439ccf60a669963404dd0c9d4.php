<?php

use App\Models\User;
?>
<?php if(auth()->guard()->guest()): ?>
    <div class="card-body">
        <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php else: ?>
    <?php if(auth()->guard()->check()): ?>
    <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 500px;">
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $class = ' alert-info';
                $class = $report->iStatus == 1? 'alert-success': $class;
                $class = $report->iStatus == 3? ' alert-danger': $class;

                $status = 'Chưa xử lý';
                $status = $report->iStatus == 1? 'Đã xử lý': $status;
                $status = $report->iStatus == 3? 'Từ chối xử lý': $status;
            ?>
            <div class="alert ntp_default ntp_alert_static <?php echo e($class); ?>" role="alert">
                <h4 class="alert-heading">Tiêu đề: <?php echo e($report->sTitle); ?></h4>
                <?php
                $user = User::find($report->idUser);
                ?>
                <div class="d-flex justify-content-between flex-wrap">
                    <span class="mb-0">Nguời tố cáo: <?php echo e($user->name); ?></span> 
                    <span class="mb-0">Email: <?php echo e($user->email); ?></span> 
                    <span class="mb-0">Trạng thái xử lý: <?php echo e($status); ?></span> 
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <span class="mb-0">Ngày khởi tạo tố cáo: <?php echo e($report->dCreateDay); ?></span> 
                    <a href="#" class="btn btn-primary ntp_btn_report_detail_user" data-bs-toggle="modal" data-bs-target="#ntp_report_detail" data-link="<?php echo e(route('Report.chitiet_report_user', [$report->id])); ?>">Chi tiết</a>
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/user/report/report_list_user.blade.php ENDPATH**/ ?>