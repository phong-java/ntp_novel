

<div class="user_infor">
    
</div>
<form method="POST" id="ntp_form_admin_report_update" action="<?php echo e(route('Report.update_report_admin', [$report->id])); ?>">
    <div class="alert alert-success ntp_hidden" role="alert"></div>
    <div class="alert alert-danger ntp_hidden" role="alert"></div>
    <div class="mb-3">
        <label class="small mb-1" for="report_title">Tiêu đề báo cáo:</label><span> <?php echo e($report->sTitle); ?></span>
    </div>

    <div class="mb-3">
        <label class="small mb-1">Nội dung báo cáo</label>
        <div><?php echo e($report->sContent); ?></div>
    </div>

    <div class="mb-3">
        <label class="small mb-1">Nội dung phản hồi</label>
        <textarea name="report_reply" id="report_reply" rows="10" maxlength="3000" class="w-100"><?php echo e($report->sReply); ?></textarea>
    </div>

    <select class="form-select" aria-label="Default select example" name="report_status" id="">
        <option <?php echo($report->iStatus== 0 ? 'selected':'');?> value="0">Chưa xử lý</option>
        <option <?php echo($report->iStatus== 1 ? 'selected':'');?> value="1">Đã xử lý</option>
        <option <?php echo($report->iStatus== 3 ? 'selected':'');?> value="3">Từ chối xử lý</option>
    </select>
</form>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/admincp/admin_page/report/report_detail_admin.blade.php ENDPATH**/ ?>