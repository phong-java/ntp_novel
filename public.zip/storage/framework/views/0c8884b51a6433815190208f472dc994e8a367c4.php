

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 mb-5">
                <div class="card">
                    <div class="card-header fw-bold">
                        <div id="pills-tab" role="tablist">
                            <div class="btn-group ntp_dropdown">
                                <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-flag"></i> Xin chào, bạn đang ở trang quản lý báo cáo cá nhân?</button>
                                <ul class="dropdown-menu dropdown-menu-lg-end">
                                    <li>
                                        <button class="active dropdown-item" id="user_add_report-tab" data-bs-toggle="pill"
                                        data-bs-target="#user_add_report" type="button" role="tab"
                                        aria-controls="user_add_report" aria-selected="true"><i class="fa-solid fa-pen-to-square"></i> Viết báo cáo mới</button>
                                    </li>
    
                                    <li>
                                        <button class="dropdown-item" id="user_report_list-tab" data-bs-toggle="pill"
                                        data-bs-target="#user_report_list" type="button" role="tab"
                                        aria-controls="user_report_list" aria-selected="true"><i class="fa-solid fa-list"></i> Danh sách báo cáo của tôi</button>
                                    </li>
    
                                </ul>
                            </div>
                        </div>

                    </div>

                    <div class="card-body">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade" id="user_add_report" role="tabpanel"
                                aria-labelledby="user_add_report-tab">
                               thêm báo cáo
                            </div>
                            <div class="tab-pane fade" id="user_report_list" role="tabpanel"
                                aria-labelledby="user_report_list-tab">
                                Danh sách báo cáo
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/report/report_page.blade.php ENDPATH**/ ?>