<?php

use App\Models\User;
use App\Models\Author;
use App\Models\Novel;
use App\Models\Chapter;

?>

<div class="container" id="ntp_admin_user_list_wrap">
    <div class="alert alert-success ntp_hidden" role="alert"></div>
    <div class="alert alert-danger ntp_hidden" role="alert"></div>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold">Danh sách người dùng</div>
                <?php if(auth()->guard()->guest()): ?>
                    <div class="card-body">
                        <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php else: ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->sRole == 'admin'): ?>
                            <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 1000px;">
                                <table class="table table-hover ntp_user_list">
                                    <thead>
                                        <tr>
                                            <th scope="col">STT</th>
                                            <th scope="col">Avarta</th>
                                            <th scope="col">Tên</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Quyền</th>
                                            <th scope="col">kích hoạt tài khoản</th>
                                            <th scope="col">khóa bình luận</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->id !== Auth::user()->id): ?>
                                                <?php
                                                $avtar = $user->sAvatar != '' ? $user->sAvatar : 'default-avatar-photo.jpg';
                                                ?>
                                                <tr class="ntp_user_wrap">
                                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                                    <td class="avrtar"> <img class="ntp_av shadow-lg rounded-5"
                                                            src="<?php echo e(asset('uploads/user_av/' . $avtar)); ?>" alt="<?php echo e($avtar); ?>"></td>
                                                    <td><?php echo e($user->name); ?></td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td>
                                                        <select
                                                            data-link="<?php echo e(route('User.cap_quyen_user', [$user->id])); ?>"
                                                            name="admin_user_role" class="admin_user_role_sl">
                                                            <option <?php echo $user->sRole == 'admin' ? 'selected' : ''; ?> value="admin">admin</option>
                                                            <option <?php echo $user->sRole == 'author' ? 'selected' : ''; ?> value="author">author</option>
                                                            <option <?php echo $user->sRole == 'user' ? 'selected' : ''; ?> value="user">user</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch p-0 w-auto d-flex justify-content-center align-content-center">
                                                            <input 
                                                                data-link="<?php echo e(route('User.khoa_user', [$user->id])); ?>"
                                                                class="form-check-input admin_user_status position-static m-0"
                                                                type="checkbox"
                                                                name="admin_user_status"
                                                                 <?php echo $user->iStatus == 1 ? 'checked' : ''; ?>>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch p-0 w-auto d-flex justify-content-center align-content-center">
                                                            <input
                                                                data-link="<?php echo e(route('User.khoa_comment_user', [$user->id])); ?>"
                                                                class="form-check-input position-static m-0 admin_user_comment"
                                                                type="checkbox"
                                                                name="admin_user_comment"
                                                                <?php echo $user->iComment == 1 ? 'checked' : ''; ?>>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="card-body">
                                <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/admincp/admin_page/admin_danhsach_nguoidung.blade.php ENDPATH**/ ?>