<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>file báo cáo</h1>
     
    <p>Thank you</p>
</body>
</html><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/emails/myTestMail.blade.php ENDPATH**/ ?>