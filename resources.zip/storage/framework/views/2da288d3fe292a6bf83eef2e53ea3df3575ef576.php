<nav class="ntp_nav navbar navbar-expand-lg  bg-body shadow-sm mb-4">
    <div class="container col-md-11 justify-content-between">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="ntp_logo me-2"
            src="<?php echo e(asset('uploads/logo/Logo.jpg')); ?>" alt="">TNP Novel 
            <?php if(isset($isadmin) && $isadmin): ?>
            - Admin
            <?php endif; ?>
    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse flex-grow-0" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="navbar-nav ms-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link d-flex gap-2 align-items-center" href="#" data-bs-toggle="modal" data-bs-target="#ntp_login_register_modal"><i class="fa-regular fa-user"></i>Đăng nhập / Đăng ký</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown ntp_dropdown">
                        <a id="navbarDropdown" class="ntp_user_loged nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>

                            <div class="ntp_av_nav overflow-hidden rounded-circle">
                                <?php  
                                    $avatar = Auth::user()->sAvatar != ''? Auth::user()->sAvatar:'default-avatar-photo.jpg';
                                ?>
                                <img class="ntp_av_nav ntp_av" src="<?php echo e(asset('uploads/user_av/'.$avatar)); ?>" alt="<?php echo e($avatar); ?>">
                            </div>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-lg-end dropdown-menu dropdown-menu-lg-end-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                            </a>

                            <a class="dropdown-item" href="<?php echo e(route('User.show', [Auth::user()->id])); ?>"><i class="fa-solid fa-user"></i> Trang cá nhân</a>

                            <a class="dropdown-item" href="<?php echo e(route('User.show', [Auth::user()->id,'view=user_report-tab'])); ?>"><i class="fa-solid fa-flag"></i> Tố cáo</a>

                            <a class="dropdown-item" href="<?php echo e(route('User.show', [Auth::user()->id,'view=user_bill-tab'])); ?>"><i class="fa-solid fa-coins"></i> Ví tiền và hóa đơn</a>

                            <?php if(Auth::user()->email_verified_at == null): ?>
                                <a class="dropdown-item" href="<?php echo e(route('verification.notice')); ?>"><i class="fa-solid fa-envelope"></i> Xác thực email</a>
                            <?php else: ?>
                                <?php if(Auth::user()->sRole == 'admin'): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('User.admin',[Auth::user()->id])); ?>"><i class="fa-solid fa-user-tie"></i> Trang quản trị</a>
                                <?php endif; ?>

                                <a class="dropdown-item" href="<?php echo e(route('Author.show',[Auth::user()->id])); ?>"><i class="fa-solid fa-pen-nib"></i> Trang tác giả</a>
                            <?php endif; ?>
                           
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/layouts/nav.blade.php ENDPATH**/ ?>