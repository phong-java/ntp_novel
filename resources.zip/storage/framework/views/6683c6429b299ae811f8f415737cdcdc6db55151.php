<?php
use App\Models\Categories;
use Illuminate\Support\Str;

$cats = Categories::orderBy('id', 'DESC')->where('iStatus', 1)->get();

$count = $chapters->count();
$matchingIds = [];

foreach ($theloai as $loai) {
    foreach ($cats as $cat) {
        if ($cat->id == $loai->idCategories) {
            $matchingIds[] = $cat->id;
        }
    }
}

?>


<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
    <div class="container">
        <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div> 
    <?php else: ?>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->sRole !== 'user' && Auth::user()->id == $novel->idUser): ?>
                <div class="container">
                    <div class="row mb-5">
                        <div class="col-xl-4">
                            <!-- Profile picture card-->
                            <div class="card  mb-xl-0">
                                <div class="card-header fw-bold">Ảnh bìa truyện</div>
                                <div class="card-body ntp_anh_bia_wrap text-center">
                                    <!-- Profile picture image-->
                                    <img class="ntp_anh_bia ntp_detail_novel mb-2 w-100" src="<?php echo e(asset('uploads/images/' . $novel->sCover)); ?>"
                                        alt="<?php echo e($novel->sCover); ?>">
                                    <!-- Profile picture help block-->
                                    <div class="my-3">
                                        <div class="alert alert-success ntp_hidden update_anhdaidien" role="alert"></div>
                                        <div class="alert alert-danger ntp_hidden update_anhdaidien" role="alert"></div>
                                        <label for="ntp_input_anhbiatruyen" class="btn m-0 btn-primary form-label">Chọn ảnh bìa</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8">
                            <!-- Account details card-->
                            <div class="card ">
                                <div class="card-header fw-bold">Thông tin chi tiết truyện</div>
                                <div class="card-body">
                                    <?php if( $novel->iLicense_Status == 3): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <span class="ntp_alert_close bg-danger"><button type="button" class="btn-close"></button></span>
                                        Việc xin kiểm duyệt truyện của bạn đã bị từ chối hãy kiểm tra lại kĩ thông tin bạn cung cấp, và các thông tin mô tả, xác thực bản quyền. Nếu có lỗi làm ơn hãy viết tố cáo. TNP Xin cám ơn.</div>
                                    <?php endif; ?>
                                    <form method="POST" id="ntp_form_create_novel"
                                        action="<?php echo e(route('Novel.update', [$novel->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>
                                        <input class="form-control d-none" type="file" id="ntp_input_anhbiatruyen" name="anhbia"
                                            accept="image/*">
                                        <div class="alert alert-success ntp_hidden" role="alert"></div>
                                        <div class="alert alert-danger ntp_hidden" role="alert"></div>

                                        <div class="mb-3">
                                            <label class="small mb-1" for="inputnovelname">Tên truyện</label>
                                            <input class="form-control" id="inputnovelname" maxlength="255"
                                                value="<?php echo e($novel->sNovel); ?>" name="tentruyen" type="text"
                                                placeholder="Tên truyện là">
                                        </div>
                                        <div class="mb-3">
                                            <label class="small mb-1">Mô tả</label>
                                            <textarea name="motatruyen" id="motatruyen" class="ntp_ckeditor ckeditor w-100" ><?php echo e(htmlspecialchars_decode($novel->sDes)); ?></textarea>
                                        </div>
                                        <div class="gx-3 mb-3 input-group">
                                            <button type="button" class="btn btn-outline-secondary dropdown-toggle"
                                                data-bs-auto-close="outside" data-bs-toggle="dropdown" aria-expanded="false"> Thể
                                                loại</button>
                                            <div class="dropdown-menu dropdown-menu-lg-end">
                                                <div class="d-flex gap-3 flex-wrap p-2 ntp_select_the_loai overflow-auto ntp_custom_ver_scrollbar"
                                                    role="group" aria-label="Basic checkbox toggle button group">

                                                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <input class="form-check-input btn-check"
                                                            <?php echo e(in_array($cat->id, $matchingIds) ? 'checked' : ''); ?> type="checkbox"
                                                            autocomplete="off" value="<?php echo e($cat->id); ?>" name="theloai[]"
                                                            id="<?php echo e(Str::slug($cat->sCategories) . '_' . $cat->id); ?>">
                                                        <label class="btn btn-outline-primary"
                                                            for="<?php echo e(Str::slug($cat->sCategories) . '_' . $cat->id); ?>"><?php echo e($cat->sCategories); ?></label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="gx-3 mb-3">
                                            <label class="small mb-1">Tiến độ</label>
                                            <select class="form-select" name="tiendo" id="inputnovelprogress"
                                                aria-label="Default select example">
                                                <option <?php echo $novel->sProgress == '1' ? 'selected' : ''; ?> value="1">Còn tiếp</option>
                                                <option <?php echo $novel->sProgress == '2' ? 'selected' : ''; ?> value="2">Tạm ngừng</option>
                                                <option <?php echo $novel->sProgress == '3' ? 'selected' : ''; ?> value="3">Hoàn thành</option>
                                            </select>
                                        </div>

                                        <div class="gx-3 mb-3">
                                            <label class="form-label">Minh chứng quyền tác giả / quyền sở hữu với tác phẩm đã cung cấp</label>
                                            <iframe id="ntp_banquyen_da_upload" src="<?php echo e(asset('uploads/banquyen/' . $novel->sLicense)); ?>" class="w-100 vh-100"></iframe>
                                        </div>
                                        <?php if($novel->iLicense_Status != 1): ?>
                                            <div class="gx-3 mb-3">
                                                <label for="upload_banquyen" class="form-label">Minh chứng quyền tác giả hoặc quyền sở hữu với tác phẩm</label>
                                                <input class="form-control mb-3" type="file" name="banquyen" id="upload_banquyen">
                                            </div>
                                        <?php endif; ?>

                                        <!-- Save changes button-->
                                        <button class="btn btn-primary ntp_btn_update_infor_novel" type="button">Cập nhật</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-md-12 mb-5">
                            <div class="card">
                                <div class="card-header">Thêm chương mới</div>
                                <div class="card-body">
                                    <form method="POST" id="ntp_form_create_chapter" action="<?php echo e(route('Chapter.store')); ?>">
                                        <div class="alert alert-success ntp_hidden" role="alert"></div>
                                        <div class="alert alert-danger ntp_hidden" role="alert"></div>
                                        <input type="hidden" value="<?php echo e($novel->id); ?>" name="idNovel">
                                        <div class="mb-3">
                                            <label class="small mb-1" for="inputchaptername">Tên chương</label>
                                            <input class="form-control" id="inputchaptername" maxlength="255" name="tenchuong"
                                                type="text" placeholder="Tên chương là">
                                        </div>

                                        <div class="mb-3">
                                            <label class="small mb-1">Nội dung chương</label>
                                            <textarea name="noidungchuong" id="noidungchuong" class="ntp_ckeditor ckeditor w-100"></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label class="small mb-1">Đăng tải không ?</label>
                                            <select class="form-select" name="tinhtrang" aria-label="Default select example">
                                                <option value="1" selected>Đăng tải</option>
                                                <option value="0">Không đăng tải</option>
                                            </select>
                                        </div>
                                        <?php if($count>= 10): ?>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Có tính phí không</label>
                                                    <select class="form-select" name="tinhphi" aria-label="Default select example">
                                                        <option value="0" selected>Không tính phí</option>
                                                        <option value="1">Tính phí</option>
                                                    </select>
                                                </div>

                                                <div class="col-md-6">
                                                    <label class="small mb-1" for="inputchapterprice">Giá tiền</label>
                                                    <input class="form-control" id="inputchapterprice" name="giatien" value="1" type="number" min="0" placeholder="Giá tiền bạn đặt cho chương này là (Nếu không nhập sẽ mặc định là 1)">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <!-- Save changes button-->
                                        <button class="btn btn-primary ntp_btn_create_chapter" type="button">Thêm mới</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12 mb-5">
                            <?php echo $__env->make('author.novel.single_mucluc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
            <div class="container">
                <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> 
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/author/novel/novel_index.blade.php ENDPATH**/ ?>