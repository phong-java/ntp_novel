
<?php
use App\Models\Chapter;
?>
<div class="container" id="ntp_novel_list_wrap">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header fw-bold">Danh sách truyện đã đăng</div>
                <?php if(auth()->guard()->guest()): ?>
                <div class="card-body">
                    <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php else: ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->sRole !== 'user'): ?>
                    <div class="card-body overflow-auto ntp_custom_ver_scrollbar" style="height: 1000px;">
                        <table class="table table-hover ntp_novel_list">
                            <thead>
                                <tr>
                                    <th scope="col">STT</th>
                                    
                                    <th scope="col">Ảnh bìa</th>
                                    <th scope="col">Tên truyện</th>
                                    <th scope="col">Số chương</th>
                                    <th scope="col">Tiến độ</th>
                                    <th scope="col">Trạng thái đăng tải</th>
                                    <th scope="col">Xét duyệt bản quyền</th>
                                    <th scope="col">Ngày khởi tạo</th>
                                    <th scope="col">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>


                                <?php $__currentLoopData = $novels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $novel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                        
                                        <td> <img class="ntp_anh_bia mb-2 w-100" src="<?php echo e(asset('uploads/images/'.$novel->sCover)); ?>" alt="<?php echo e($novel->sCover); ?>"></td>
                                        <td class="name"><?php echo e($novel->sNovel); ?></td>
                                        <td><?php echo e(Chapter::orderBy('iChapterNumber', 'ASC')->where('idNovel',$novel->id)->get()->count()); ?> Chương</td>
                                        <td>
                                            <?php if($novel->sProgress == 1): ?>
                                                <span class="text text-success">Còn tiếp</span>
                                            <?php elseif($novel->sProgress == 2): ?>
                                                <span class="text text-warning">Tạm ngưng</span>
                                            <?php elseif($novel->sProgress == 3): ?>
                                                <span class="text text-danger">Hoàn thành</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($novel->iStatus == 1): ?>
                                                <span class="text text-success">Đăng tải</span>
                                            <?php else: ?>
                                                <span class="text text-danger">Đã bị ghỡ bỏ</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($novel->iLicense_Status == 1): ?>
                                                <span class="text text-success">Thông qua</span>
                                            <?php elseif($novel->iLicense_Status == 0): ?>
                                                <span class="text text-danger">Chưa xét duyệt</span>
                                            <?php elseif($novel->iLicense_Status == 3): ?>
                                                <span class="text text-danger">Không thông qua</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($novel->dCreateDay); ?></td>
                                        <td>
                                            <a class="btn btn-primary" href="<?php echo e(route('Novel.quan_ly_truyen',[$novel->id])); ?>">Quản lý truyện</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="card-body">
                            <?php echo $__env->make('layouts.404_traiphep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/author/novel/novel_list.blade.php ENDPATH**/ ?>