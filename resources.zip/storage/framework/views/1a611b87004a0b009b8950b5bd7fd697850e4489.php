<?php

use Carbon\Carbon;

?>
<div class="card">
    <div class="card-header fw-bold">Mục lục</div>
    <div class="card-body">
        <div class="overflow-auto ntp_custom_ver_scrollbar" style="height: 500px;">
            <table class="table table-hover">
                <thead>
                    <tr>
                        
                        <th scope="col">Tên chương</th>
                        <th scope="col">Ngày đăng</th>
                        <th scope="col">Giá tiền</th>
                        <th scope="col">Tình trạng xét duyệt</th>
                        <th scope="col">Trạng thái đăng tải</th>
                        <th scope="col">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('Chapter.show', [1])); ?>"
                                    class="title text-decoration-none text-reset fw-bold"> Chương <?php echo $chapter->iChapterNumber; ?>:
                                    <?php echo e($chapter->sChapter); ?>.
                                </a>
                            </td>
                            <td>
                                <?php
                                
                                $time = Carbon::parse($chapter->dCreateDay);
                                $time = $time->locale('Vi');
                                
                                // Tính khoảng thời gian so với thời điểm hiện tại
                                $diff = $time->diffForHumans();
                                
                                echo $diff;
                                ?>
                            </td>
                            <td><?php echo e($chapter->iPrice); ?></td>
                            <td>
                                <?php if($chapter->iPublishingStatus == 1): ?>
                                    <span class="text text-success">Đã qua kiểm duyệt</span>
                                <?php elseif($chapter->iPublishingStatus == 2): ?>
                                    <span class="text text-danger">Không qua kiểm duyệt</span>
                                <?php elseif($chapter->iPublishingStatus == 0): ?>
                                    <span class="text text-danger">Chưa qua kiểm duyệt</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($chapter->iStatus == 1): ?>
                                    <span class="text text-success">Đã đăng tải</span>
                                <?php elseif($chapter->iStatus == 0): ?>
                                    <span class="text text-danger">Đã gỡ bỏ</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(route('Chapter.page_chitiet_chuong_author',[$chapter->id])); ?>">Chi tiết chương truyện</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\wamp_intall\www\ntp_novel\resources\views/author/novel/single_mucluc.blade.php ENDPATH**/ ?>